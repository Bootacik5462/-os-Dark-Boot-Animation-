#!/system/bin/sh
# Bootanimation yükleme scripti

MODPATH=${0%/*}

# Bootanimation.zip'i sisteme kopyala
cp -af $MODPATH/system/* /system_root/system/
