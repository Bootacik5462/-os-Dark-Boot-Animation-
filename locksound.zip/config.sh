#!/system/bin/sh
# iOS Shutdown Sound Magisk Module
# No special actions needed
